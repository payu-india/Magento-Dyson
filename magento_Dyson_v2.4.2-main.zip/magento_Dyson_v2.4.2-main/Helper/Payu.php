<?php

namespace PayUIndia\Payu\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Sales\Model\Order;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\Exception\LocalizedException;


class Payu extends AbstractHelper
{
    private $session;
    private $customerSession;
    private $quote;
    private $quoteManagement;
    private $orderSender;
    private $_storeManager;
    private $customerFactory;
    private $customerRepository;
    private $orderService;
    private $cartManagement;
    protected $order;
    protected $scopeConfig;
    protected $shipconfig;
    protected $payuEventLog;
    protected $payuEventCollection;
    protected $payuWebhook;
    protected $payuWebhookCollection;
    protected $customerCollectionFactory;



    public function __construct(
        Context $context,
        \Magento\Checkout\Model\Session $session,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Quote\Model\Quote $quote,
        \Magento\Quote\Model\QuoteManagement $quoteManagement,
        \Magento\Quote\Api\CartManagementInterface $cartManagement,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
        \Magento\Sales\Model\Service\OrderService $orderService,
        \Magento\Sales\Api\Data\OrderInterface $order,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Shipping\Model\Config $shipconfig

    ) {
        $this->session = $session;
        $this->quote = $quote;
        $this->order = $order;
        $this->quoteManagement = $quoteManagement;
        $this->cartManagement = $cartManagement;
        $this->customerSession = $customerSession;
        $this->_storeManager = $storeManager;
        $this->customerFactory = $customerFactory;
        $this->customerRepository = $customerRepository;
        $this->orderService = $orderService;
        $this->shipconfig = $shipconfig;
        $this->scopeConfig = $scopeConfig;
        parent::__construct($context);
    }

    public function cancelCurrentOrder($comment)
    {
        $order = $this->session->getLastRealOrder();
        if ($order->getId() && $order->getState() != Order::STATE_CANCELED) {
            $order->registerCancellation($comment)->save();
            return true;
        }
        return false;
    }

    public function restoreQuote()
    {
        return $this->session->restoreQuote();
    }

    public function getUrl($route, $params = [])
    {
        return $this->_getUrl($route, $params);
    }

    public function createTempOrder($txnId)
    {
        $quote = $this->session->getQuote();

        if ($this->scopeConfig->getValue('payment/payu/paymentaction') == 'expresscheckout') {
            $store = $this->_storeManager->getStore();
            $websiteId = $this->_storeManager->getStore()->getWebsiteId();
            $customer = $this->customerFactory->create();
            $customer->setWebsiteId($websiteId);

            if ($this->customerSession->isLoggedIn()) {
                $email = $this->customerSession->getCustomer()->getEmail();
                $fname = $this->customerSession->getCustomer()->getFirstname() ?? '';
                $lname = $this->customerSession->getCustomer()->getLastname() ?? '';
            } else {
                $email = 'guestuser' . uniqid() . time() . '@gmail.com';
                $fname = 'fname';
                $lname = 'lname';
            }
            $customer->loadByEmail($email);
            if (!$customer->getEntityId()) {
                $quote->setCustomerEmail($email);
                $quote->setCustomerIsGuest(true);
            } else {
                $customer = $this->customerRepository->getById($customer->getEntityId());
                $quote->assignCustomer($customer);
            }
            $address = $quote->getBillingAddress()->getData();

            $address = [
                'firstname' => 'guest',
                'lastname' => 'user',
                'street' => 'street',
                'city' => 'city',
                'country_id' => 'US',
                'region' => 'xxx',
                'region_id' => '1',
                'postcode' => 'XXXXXX',
                'telephone' => '0123456789',
                'fax' => '',
                'save_in_address_book' => 0
            ];

            //Set Address to quote
            $quote->getBillingAddress()->addData($address);
            $quote->getShippingAddress()->addData($address);

            $activeCarriers = $this->getShippingMethods();

            $shippingAddress = $quote->getShippingAddress();
            $shippingAddress->setCollectShippingRates(true)
                ->collectShippingRates()
                ->setShippingMethod($activeCarriers[0]['value'][0]['value']);

            $quote->setInventoryProcessed(false);
            $quote->setPaymentMethod('payu');
            $quote->save();
            $quote->getPayment()->importData(['method' => 'payu']);
            $quote->collectTotals()->save();
        } else {
            if ($this->customerSession->isLoggedIn()) {
                $email = $this->customerSession->getCustomer()->getEmail();
                $fname = $this->customerSession->getCustomer()->getFirstname() ?? '';
                $lname = $this->customerSession->getCustomer()->getLastname() ?? '';
                $quote->setCustomerEmail($email);

            }
            $quote->setInventoryProcessed(false);
            $quote->setPaymentMethod('payu');
            $quote->save();
            $quote->getPayment()->importData(['method' => 'payu']);
            $quote->collectTotals()->save();
        }

        // Create Order From Quote
        $orderid = $this->cartManagement->placeOrder($quote->getId());
        $m2order = $this->order->load($orderid);
        $m2order->setState(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT);
        $m2order->setStatus('pending_payment');
        $m2order->setIsNotified(false);
        $payment = $m2order->getPayment();
        if ($payment) {
            $payment->setAdditionalInformation('txnid', $txnId);
            $payment->save();
        }
        $increment_id = $m2order->getRealOrderId();
        $m2order->setCanSendNewEmailFlag(false)->save();
        if ($m2order->getEntityId()) {
            $result['order_id'] = $m2order->getRealOrderId();
        } else {
            $result = ['error' => 1, 'msg' => 'erro message'];
        }
        return $result;
    }

    public function getShippingMethods()
    {
        $activeCarriers = $this->shipconfig->getActiveCarriers();

        foreach ($activeCarriers as $carrierCode => $carrierModel) {
            $options = array();

            if ($carrierMethods = $carrierModel->getAllowedMethods()) {
                foreach ($carrierMethods as $methodCode => $method) {
                    $code = $carrierCode . '_' . $methodCode;
                    $options[] = array('value' => $code, 'label' => $method);
                }
                $carrierTitle = $this->scopeConfig
                    ->getValue('carriers/' . $carrierCode . '/title');
            }

            $methods[] = array('value' => $options, 'label' => $carrierTitle);
        }

        return $methods;
    }

    public function getConfigData($value, $storeId = null)
    {
        if ($storeId === null) {
            $storeId = $this->_storeManager->getStore()->getId();
        }
        return $this->scopeConfig->getValue(
            'payment/payu/' . $value,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    public function updateOrderFromResponse($order, $params)
    {
        if (isset($params['offer']) && isset($params['offer_availed']) && isset($params['transaction_offer'])) {
            $offerArr = $params['transaction_offer'];
            if (!is_array($offerArr)) {
                $offerArr = json_decode($offerArr, true);
            }
            if (isset($offerArr['offer_data'])) {
                $des = $offerArr['offer_data'];
                $description = $des[0];
                $discountDescription = "Title - " . $description['offer_title'] . " | Offer Key - " . $description['offer_key'] . " |  Type - " . $description['offer_type'];
                $customDiscount = $offerArr['discount_data']['total_discount'];
                if ($customDiscount > 0) {
                    $this->setDiscount($order, $customDiscount, $discountDescription);
                }
            }

        } else {
            if (isset($params['disc']) && $params['disc'] > 0) {
                $discountDescription = 'Payu Offer';
                $customDiscount = $params['disc'];
                $this->setDiscount($order, $customDiscount, $discountDescription);
            }
        }

    }

    public function setDiscount($order, $customDiscount, $discountDescription)
    {
        $total = $order->getGrandTotal();
        $existingDiscount = $order->getDiscountAmount();
        $newDiscount = $existingDiscount - $customDiscount; // Adding the custom discount
        $order->setDiscountAmount($newDiscount);
        $order->setBaseDiscountAmount($newDiscount);
        $order->setGrandTotal($order->getGrandTotal() - $customDiscount);
        $order->setBaseGrandTotal($order->getBaseGrandTotal() - $customDiscount);
        $order->setDiscountDescription($order->getDiscountDescription() . '|||payu :-' . $discountDescription);
        $shippingAddress = $order->getShippingAddress();
        if ($shippingAddress) {
            $shippingAddress->setDiscountAmount($customDiscount);
            $shippingAddress->setDiscountDescription($discountDescription);
            $shippingAddress->setBaseDiscountAmount($customDiscount);
        }
        // Apply discount to billing address if exists
        $billingAddress = $order->getBillingAddress();
        if ($billingAddress) {
            $billingAddress->setDiscountAmount($customDiscount);
            $billingAddress->setDiscountDescription($discountDescription);
            $billingAddress->setBaseDiscountAmount($customDiscount);
        }
 
        $order->setSubtotal((float) $order->getSubTotal());
        $order->setBaseSubtotal((float) $order->getBaseSubtotal());
        $order->setGrandTotal((float) $order->getGrandTotal());
        $order->setBaseGrandTotal((float) $order->getBaseGrandTotal());
        $order->addStatusHistoryComment('discount-' . $existingDiscount . 'payu discount-' . $customDiscount);
        $order->save();
 
        $order->setBaseTotalInvoiced($order->getGrandTotal());
        $order->setTotalInvoiced($order->getGrandTotal());
 
        $payment = $order->getPayment();
        $payment->setBaseAmountPaid($order->getGrandTotal());
        $payment->setAmountPaid($order->getGrandTotal());
        $payment->setBaseAmountOrdered($order->getGrandTotal());
        $payment->setAmountOrdered($order->getGrandTotal());
        $payment->save();
        $totalNew = 0;
        $totalNewTaxAmount = 0;
        $orderParent = [];
        foreach ($order->getAllItems() as $item) {
                $orderParent[$item->getItemId()] = $item;
                if($item->getProductType() !="bundle" && $item->getProductType() !="soft") {
                     if($item->getParentItemId() == null || ($orderParent[$item->getParentItemId()]->getProductType() =="bundle" || $orderParent[$item->getParentItemId()]->getProductType() =="soft"))
                         $totalNew=$totalNew+($item->getPriceInclTax()*$item->getQtyOrdered())-$item->getDiscountAmount();
               }
        }
        // Distribute the discount proportionally among items
        foreach ($order->getAllItems() as $item) {
             if($item->getProductType() !="bundle" && $item->getProductType() !="soft") {
                     if($item->getParentItemId() == null || ($orderParent[$item->getParentItemId()]->getProductType() =="bundle" || $orderParent[$item->getParentItemId()]->getProductType() =="soft"))
                     {
                        $itemPriceInclTax = ($item->getPriceInclTax() * $item->getQtyOrdered()) - $item->getDiscountAmount();
                        $discountRatio = $itemPriceInclTax / $totalNew;
                        $itemDiscountAmount = $discountRatio * abs($customDiscount);
                        $item->setBaseDiscountAmount($item->getBaseDiscountAmount() + $itemDiscountAmount);
                        $item->setDiscountAmount($item->getDiscountAmount() + $itemDiscountAmount);
                        //calculate new tax and  discount tax compensation amount
                        $oldTaxAmount = $item->getTaxAmount();
                        $newTaxAmount=  round(($itemPriceInclTax - $itemDiscountAmount) /( 1 + $item->getTaxPercent()/100)*($item->getTaxPercent()/100),2);
                        $totalNewTaxAmount += $newTaxAmount;
                        $discountTaxCompensationAmount = $oldTaxAmount - $newTaxAmount;
                        $item->setTaxAmount($newTaxAmount);
                        $item->setBaseTaxAmount($newTaxAmount);
                        $item->setDiscountTaxCompensationAmount(
                            $item->getDiscountTaxCompensationAmount() + $discountTaxCompensationAmount
                        );
                        $item->setBaseDiscountTaxCompensationAmount(
                            $item->getBaseDiscountTaxCompensationAmount() + $discountTaxCompensationAmount
                        );
                        $item->save();
                     }
             }
        }
        // Adjust new tax and  discount tax compensation amount order level
        $orderOldTaxAmount = $order->getTaxAmount();
        $orderDiscountTaxCompensationAmount = $orderOldTaxAmount - $totalNewTaxAmount;
        $order->setTaxAmount($totalNewTaxAmount);
        $order->setBaseTaxAmount($totalNewTaxAmount);
        $order->setDiscountTaxCompensationAmount(
            $order->getDiscountTaxCompensationAmount() + $orderDiscountTaxCompensationAmount
        );
        $order->setBaseDiscountTaxCompensationAmount(
            $order->getBaseDiscountTaxCompensationAmount() + $orderDiscountTaxCompensationAmount
        );
        $order->save();
    }
    public function getTxnIdByOrder($order)
    {
        if (!$order || !$order->getId()) {

            return null;
        }
        $payment = $order->getPayment();
        if ($payment) {
            return $payment->getAdditionalInformation('txnid') ?? null;
        }
        return null;
    }

}
